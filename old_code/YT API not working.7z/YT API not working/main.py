import os, pickle, json, openpyxl, time
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
from googleapiclient.discovery import build

class pyYtMng():
    def __init__(self):

        # get the required credentials
        self.credentials = None
        self.all_data = {}
        
        # If the credentials are on the local storage load them
        if os.path.exists('token.pickle'):
            print('Loading credentials from file ...')
            with open('token.pickle', 'rb') as token:
                self.credentials = pickle.load(token)
        
        # If there are no valid credentials available, then either refresh the token or log in.
        if not self.credentials or not self.credentials.valid:
            if self.credentials and self.credentials.expired and self.credentials.refresh_token:
                print('Refreshing Access Token...')
                self.credentials.refresh(Request())
            else:
                print('Fetching New Tokens...')
                flow = InstalledAppFlow.from_client_secrets_file(
                    'client_secrets.json',
                    scopes=[
                        'https://www.googleapis.com/auth/youtube.readonly'
                    ]
                )
        
                flow.run_local_server(port=8080, prompt='consent',
                                      authorization_prompt_message='')
                self.credentials = flow.credentials
        
                # Save the credentials for the next run
                with open('token.pickle', 'wb') as f:
                    print('Saving Credentials for Future Use...')
                    pickle.dump(self.credentials, f)

    def get_videos_by_rating(self,
                             rating: str):

        youtube = build('youtube',
                        'v3',
                        credentials=self.credentials)

        next_page_token = None

        while True:
            if not next_page_token:
                print('Querring the first page...')
                request = youtube.videos().list(part='snippet, contentDetails',
                                                myRating=rating,
                                                maxResults=50)
                response = request.execute()

                if 'nextPageToken' in response.keys():
                    next_page_token = response['nextPageToken']
                    print('Next_page_token is now {}'.format(next_page_token))
            else:
                print('Querring page {}'.format(next_page_token))
                request = youtube.videos().list(part='snippet, contentDetails',
                                                myRating=rating,
                                                pageToken=next_page_token,
                                                maxResults=50)
                response = request.execute()

                if 'nextPageToken' in response.keys():
                    next_page_token = response['nextPageToken']
                    print('Next_page_token is now {}'.format(next_page_token))

            print(response)

            for entry in response['items']:
                self.all_data[entry['id']] = {'duration': entry['contentDetails']['duration'],
                                              'title': entry['snippet']['title'],
                                              'rating': rating}

            if 'nextPageToken' not in response.keys():
                print('Last page reached.')
                break

            time.sleep(0.5)

        with open('output.json', 'w') as json_out_handle:
            json.dump(self.all_data, json_out_handle, indent=2)

    def sync_to_excel(self):
        allow_excel_generation = False
        if len(self.all_data.keys()) == 0:
            print('No data recorded in self. Trying to load from disk...')
            if os.path.isfile('output.json'):
                with open('output.json', 'r') as json_file_handle:
                    self.all_data = json.load(json_file_handle)
                allow_excel_generation = True
        else:
            allow_excel_generation = True

        if allow_excel_generation:
            wb = openpyxl.Workbook()
            wb.create_sheet('Status')
            wb.remove(wb['Sheet'])
            ws = wb['Status']

            ws['A1'].value = 'Title'
            ws['B1'].value = 'Duration'
            ws['C1'].value = 'Rating'
            ws['D1'].value = 'Video Link'

            for row, data in enumerate(self.all_data.items(), 2):
                ws['A{}'.format(row)].value = data[1]['title']
                ws['B{}'.format(row)].value = data[1]['duration']
                ws['C{}'.format(row)].value = data[1]['rating']
                ws['D{}'.format(row)].value = 'https://youtu.be/{}'.format(data[0])

            wb.save('report.xlsx')


worker = pyYtMng()
# worker.get_videos_by_rating(rating='dislike')
worker.get_videos_by_rating(rating='like')
worker.sync_to_excel()
